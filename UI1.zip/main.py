import sys
import requests
from PyQt5 import QtCore, QtWidgets
from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QApplication, QLabel, QMainWindow
from PyQt5 import uic
from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5.QtCore import QSize


PARAM = [34.6887, 3.0311, 0.009, 'sat']
map_file = None


class MyWidget(QMainWindow):
    def __init__(self):

        super().__init__()
        self.__initUI__()

    def __initUI__(self):
        map_request = f"http://static-maps.yandex.ru/1.x/?ll={PARAM[0]},{PARAM[1]}&spn={PARAM[2]},0.002&l={PARAM[3]}"
        response = requests.get(map_request)

        self.map_file = "picture.png"

        with open(self.map_file, "wb") as file:
            file.write(response.content)

        uic.loadUi('UI1.ui', self)

        self.pixmap = QPixmap('picture.png')
        self.image = QLabel(self)
        self.image.move(100, -20)
        self.image.resize(600, 600)
        self.image.setPixmap(self.pixmap)
        self.image.show()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MyWidget()
    ex.show()
    sys.exit(app.exec_())